package com.jforeach.mazeman;

import java.io.InputStream;

import com.jforeach.mazeman.R.id;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;

public class Menu extends Activity implements OnClickListener {
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		ImageView imgMap = (ImageView) findViewById(R.id.bImage);
		double latitude = 39.033898;
		double longitude = -94.576310;

		String url = "http://maps.googleapis.com/maps/api/staticmap?center="
				+ latitude + "," + longitude + "&zoom=15&markers=" + latitude
				+ "," + longitude + "&size=240x160&sensor=false";
		new DownloadImageTask(imgMap).execute(url);
		// Connection service call
		System.out.println("in menu only");
		Button bNewGame = (Button) findViewById(R.id.bNew);
		Button bAbout = (Button) findViewById(R.id.bAbout);
		Button bPrefs = (Button) findViewById(R.id.bPrefs);
		Button bExit = (Button) findViewById(R.id.bExit);
		Button bSMS = (Button) findViewById(R.id.bSms);
		Button bMap = (Button) findViewById(R.id.bMap);
		Button bPerformance = (Button) findViewById(R.id.bPerformance);
		bNewGame.setOnClickListener(this);
		bAbout.setOnClickListener(this);
		bPrefs.setOnClickListener(this);
		bExit.setOnClickListener(this);
		bSMS.setOnClickListener(this);
		bPerformance.setOnClickListener(this);
		bMap.setOnClickListener(this);

		SharedPreferences prefs = PreferenceManager
				.getDefaultSharedPreferences(this);
		boolean skipSplash = prefs.getBoolean("skipSplash", false);
		startService(new Intent(this, ConnectionService.class));
		if (!skipSplash) {
			Intent splash = new Intent(Menu.this, Splash.class);
			startActivity(splash);
		}
	}

	@Override
	public void onClick(View view) {
		switch (view.getId()) {
		case R.id.bExit:
			Intent pie = new Intent(Menu.this, PieChart.class);
			startActivity(pie);
			break;
		case R.id.bNew:
			String[] levels = { "Maze 1", "Maze 2", "Maze 3" };
			AlertDialog.Builder builder = new AlertDialog.Builder(this);
			builder.setTitle(getString(R.string.levelSelect));
			builder.setItems(levels, new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int item) {
					Intent game = new Intent(Menu.this, Game.class);
					Maze maze = MazeCreator.getMaze(item + 1);
					game.putExtra("maze", maze);
					startActivity(game);
				}
			});
			AlertDialog alert = builder.create();
			alert.show();
			break;
		case R.id.bAbout:
			Intent about = new Intent(Menu.this, MainActivity.class);
			startActivity(about);
			break;
		case R.id.bPrefs:
			Intent prefs = new Intent(Menu.this, Timeline.class);
			startActivity(prefs);
			break;
		case R.id.bSms:
			Intent sendms = new Intent(Menu.this, SMS.class);
			startActivity(sendms);
			break;
		case R.id.bPerformance:
			Intent performanceT = new Intent(Menu.this, PerformanceMeter.class);
			startActivity(performanceT);
			break;

		case R.id.bMap:
			Intent mapA = new Intent(Menu.this, Map1.class);
			startActivity(mapA);
			break;

		}
	}

	private class DownloadImageTask extends AsyncTask<String, Void, Bitmap> {
		ImageView bmImage;

		public DownloadImageTask(ImageView bmImage) {
			this.bmImage = bmImage;
		}

		protected Bitmap doInBackground(String... urls) {
			String urldisplay = urls[0];
			Bitmap mIcon11 = null;
			try {
				InputStream in = new java.net.URL(urldisplay).openStream();
				mIcon11 = BitmapFactory.decodeStream(in);
			} catch (Exception e) {

				// Log.e("Error", e.getMessage());
				e.printStackTrace();
			}
			return mIcon11;
		}

		protected void onPostExecute(Bitmap result) {
			bmImage.setImageBitmap(result);
		}
	}

}