package com.jforeach.mazeman;

import java.util.ArrayList;
import java.util.List;

import android.app.ListActivity;
import android.content.Context;
import android.content.Intent;
import android.database.DataSetObserver;
import android.os.Bundle;
import android.widget.ListView;

public class Timeline extends ListActivity {
	Context context = this;
	ListView lv;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.timeline);
		List<String> history = new ArrayList<String>();
		Intent intent = getIntent();
		int a =TestGesture.timeLine.size();
		history.addAll(TestGesture.timeLine);
		System.out.println("the value in timeline testgesture is  "+a);
		System.out.println("\n \n the value in history testgesture is  "+history.size());
		
		if (history != null) {
			setListAdapter(new Timeline_List(this, history));

			lv = getListView();
			lv.setTextFilterEnabled(true);

		}

	}

}
