package com.jforeach.mazeman;

import java.util.ArrayList;

import org.achartengine.ChartFactory;
import org.achartengine.model.CategorySeries;
import org.achartengine.renderer.DefaultRenderer;
import org.achartengine.renderer.SimpleSeriesRenderer;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.AdapterView.OnItemSelectedListener;

public class PieChart extends Activity implements OnItemSelectedListener {
	int l = TestGesture.leftg;
	int r = TestGesture.rightg;
	int t = TestGesture.topg;
	int b = TestGesture.bottomg;
	Spinner pie_spinner;
	private String[] mMonth = new String[] { "Jan", "Feb", "Mar", "Apr", "May",
			"Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.pie_chart);
		pie_spinner = (Spinner) findViewById(R.id.spin_pie);

		ArrayList<String> pie_date = new ArrayList<String>();
		pie_date.add("Select Date");
		pie_date.add("07/28/2014");
		pie_date.add("07/29/2014");
		pie_date.add("07/30/2014");
		pie_date.add("07/31/2014");
		ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(
				this, android.R.layout.simple_spinner_item, pie_date); // selected
																		// item
																		// will
																		// look
																		// like
																		// a
																		// spinner
																		// set
																		// from
																		// XML
		spinnerArrayAdapter
				.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		pie_spinner.setAdapter(spinnerArrayAdapter);

		pie_spinner.setOnItemSelectedListener(new OnItemSelectedListener() {
			@Override
			public void onItemSelected(AdapterView<?> parentView,
					View selectedItemView, int position, long id) {
				if (position == 1) {

					openChart1();
				} else if (position == 2) {
					openChart2();
				} else if (position == 3) {
					openChart3();
				} else if (position == 4) {
					openChart();
				}
			}

			@Override
			public void onNothingSelected(AdapterView<?> parentView) {
				// your code here
			}

		});

		// Getting reference to the button btn_chart
		Button btnChart = (Button) findViewById(R.id.btn_chart);

		// Defining click event listener for the button btn_chart
		OnClickListener clickListener = new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				openChart();
			}
		};

		// Setting event click listener for the button btn_chart of the
		// MainActivity layout
		btnChart.setOnClickListener(clickListener);

	}

	private void openChart() {

		// Pie Chart Section Names
		String[] code = new String[] { "left", "right", "top", "bottom" };

		// Pie Chart Section Value
		double[] distribution = { l, r, t, b };

		// Color of each Pie Chart Sections
		int[] colors = { Color.BLUE, Color.CYAN, Color.YELLOW, Color.RED };

		// Instantiating CategorySeries to plot Pie Chart
		CategorySeries distributionSeries = new CategorySeries(
				"Gesture Recognition on " + TestGesture.dateg);
		for (int i = 0; i < distribution.length; i++) {
			// Adding a slice with its values and name to the Pie Chart
			distributionSeries.add(code[i], distribution[i]);
		}

		// Instantiating a renderer for the Pie Chart
		DefaultRenderer defaultRenderer = new DefaultRenderer();
		for (int i = 0; i < distribution.length; i++) {
			SimpleSeriesRenderer seriesRenderer = new SimpleSeriesRenderer();
			seriesRenderer.setColor(colors[i]);
			seriesRenderer.setDisplayChartValues(true);
			// Adding a renderer for a slice
			defaultRenderer.addSeriesRenderer(seriesRenderer);
		}

		defaultRenderer.setChartTitle("Gesture Recognition on "
				+ TestGesture.dateg);
		defaultRenderer.setChartTitleTextSize(20);
		defaultRenderer.setZoomButtonsVisible(true);

		// Creating an intent to plot bar chart using dataset and
		// multipleRenderer
		Intent intent = ChartFactory.getPieChartIntent(getBaseContext(),
				distributionSeries, defaultRenderer, "Gesture Recognition");

		// Start Activity
		startActivity(intent);

	}
	private void openChart1() {

		// Pie Chart Section Names
		String[] code = new String[] { "left", "right", "top","bottom" };

		// Pie Chart Section Value
		double[] distribution = { 15, 6, 9,8 };

		// Color of each Pie Chart Sections
		int[] colors = { Color.RED, Color.GREEN, Color.YELLOW ,Color.CYAN};

		// Instantiating CategorySeries to plot Pie Chart
		CategorySeries distributionSeries = new CategorySeries(
				"Gesture Recognition on " + TestGesture.dateg);
		for (int i = 0; i < distribution.length; i++) {
			// Adding a slice with its values and name to the Pie Chart
			distributionSeries.add(code[i], distribution[i]);
		}

		// Instantiating a renderer for the Pie Chart
		DefaultRenderer defaultRenderer = new DefaultRenderer();
		for (int i = 0; i < distribution.length; i++) {
			SimpleSeriesRenderer seriesRenderer = new SimpleSeriesRenderer();
			seriesRenderer.setColor(colors[i]);
			seriesRenderer.setDisplayChartValues(true);
			// Adding a renderer for a slice
			defaultRenderer.addSeriesRenderer(seriesRenderer);
		}

		defaultRenderer.setChartTitle("Gesture Recognition on 07/28/2014");
		defaultRenderer.setChartTitleTextSize(20);
		defaultRenderer.setZoomButtonsVisible(true);

		// Creating an intent to plot bar chart using dataset and
		// multipleRenderer
		Intent intent = ChartFactory.getPieChartIntent(getBaseContext(),
				distributionSeries, defaultRenderer, "Gesture Recognition");

		// Start Activity
		startActivity(intent);

	}

	private void openChart2() {

		// Pie Chart Section Names
		String[] code = new String[] { "left", "right", "top" ,"bottom" };

		// Pie Chart Section Value
		double[] distribution = { 4, 9, 11 ,8};

		// Color of each Pie Chart Sections
		int[] colors = { Color.GRAY, Color.CYAN, Color.MAGENTA ,Color.GREEN};

		// Instantiating CategorySeries to plot Pie Chart
		CategorySeries distributionSeries = new CategorySeries(
				"Gesture Recognition on " + TestGesture.dateg);
		for (int i = 0; i < distribution.length; i++) {
			// Adding a slice with its values and name to the Pie Chart
			distributionSeries.add(code[i], distribution[i]);
		}

		// Instantiating a renderer for the Pie Chart
		DefaultRenderer defaultRenderer = new DefaultRenderer();
		for (int i = 0; i < distribution.length; i++) {
			SimpleSeriesRenderer seriesRenderer = new SimpleSeriesRenderer();
			seriesRenderer.setColor(colors[i]);
			seriesRenderer.setDisplayChartValues(true);
			// Adding a renderer for a slice
			defaultRenderer.addSeriesRenderer(seriesRenderer);
		}

		defaultRenderer.setChartTitle("Gesture Recognition on 07/29/2014");
		defaultRenderer.setChartTitleTextSize(20);
		defaultRenderer.setZoomButtonsVisible(true);

		// Creating an intent to plot bar chart using dataset and
		// multipleRenderer
		Intent intent = ChartFactory.getPieChartIntent(getBaseContext(),
				distributionSeries, defaultRenderer, "Gesture Recognition");

		// Start Activity
		startActivity(intent);

	}
	private void openChart3() {

		// Pie Chart Section Names
		String[] code = new String[] { "left", "right", "top" ,"bottom"};

		// Pie Chart Section Value
		double[] distribution = { 18, 19, 5 ,8};

		// Color of each Pie Chart Sections
		int[] colors = { Color.BLUE, Color.RED, Color.YELLOW ,Color.CYAN};

		// Instantiating CategorySeries to plot Pie Chart
		CategorySeries distributionSeries = new CategorySeries(
				"Gesture Recognition on " + TestGesture.dateg);
		for (int i = 0; i < distribution.length; i++) {
			// Adding a slice with its values and name to the Pie Chart
			distributionSeries.add(code[i], distribution[i]);
		}

		// Instantiating a renderer for the Pie Chart
		DefaultRenderer defaultRenderer = new DefaultRenderer();
		for (int i = 0; i < distribution.length; i++) {
			SimpleSeriesRenderer seriesRenderer = new SimpleSeriesRenderer();
			seriesRenderer.setColor(colors[i]);
			seriesRenderer.setDisplayChartValues(true);
			// Adding a renderer for a slice
			defaultRenderer.addSeriesRenderer(seriesRenderer);
		}

		defaultRenderer.setChartTitle("Gesture Recognition on 07/30/2014");
		defaultRenderer.setChartTitleTextSize(20);
		defaultRenderer.setZoomButtonsVisible(true);

		// Creating an intent to plot bar chart using dataset and
		// multipleRenderer
		Intent intent = ChartFactory.getPieChartIntent(getBaseContext(),
				distributionSeries, defaultRenderer, "Gesture Recognition");

		// Start Activity
		startActivity(intent);

	}

	@Override
	public void onItemSelected(AdapterView<?> parent, View view, int position,
			long id) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onNothingSelected(AdapterView<?> parent) {
		// TODO Auto-generated method stub

	}
}