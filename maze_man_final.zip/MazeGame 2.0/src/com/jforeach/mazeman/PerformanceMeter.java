package com.jforeach.mazeman;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class PerformanceMeter extends Activity {

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.performance);
		TextView t1 = (TextView) findViewById(R.id.txtLevel);

		ImageView img1 = new ImageView(this);
		img1 = (ImageView) findViewById(R.id.imgLevelr);
		int test = 40;
		int x = 0, y = 0, z = 0, h = 0;
		x = TestGesture.leftge.size();
		y = TestGesture.rightge.size();
		z = TestGesture.topge.size();
		h = x + y + z;
		if (h >= 10 && h <= 40) {
			Toast.makeText(getApplicationContext(), "Excellent Performance!",
					Toast.LENGTH_SHORT).show();
			img1.setImageResource(R.drawable.excellent);
			t1.setText("Excellent Performance!");
		} else if (h > 40 && h <= 60) {
			t1.setText("Great job. Keep rocking!");
			Toast.makeText(getApplicationContext(), "Great job. Keep rocking!",
					Toast.LENGTH_SHORT).show();
			img1.setImageResource(R.drawable.good);
		} else if (h > 60 && h <= 80) {
			t1.setText("Average Performance.You can play better!");
			Toast.makeText(getApplicationContext(),
					"Average Performance.You can play better!",
					Toast.LENGTH_SHORT).show();
			img1.setImageResource(R.drawable.concentrate);

		} else if (h > 80) {
			t1.setText("Worst Performance. Better luck next time!");
			img1.setImageResource(R.drawable.tear);
			Toast.makeText(getApplicationContext(),
					"Worst Performance. Better luck next time!",
					Toast.LENGTH_SHORT).show();
		}

	}
}
