package com.jforeach.mazeman;




import java.util.List;

import android.app.Activity;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


import android.widget.BaseAdapter;
import android.widget.TextView;

public class ListAdapter extends BaseAdapter {
	
	private List<String> course;
	private LayoutInflater inflater = null;
	int status = 0;

	public ListAdapter(Activity activity1, List<String> history) {
		// TODO Auto-generated constructor stub

		course = history;
		inflater = LayoutInflater.from(activity1);

	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub

		ViewHolder holder;
		int r;

		if (convertView == null) {
			convertView = inflater.inflate(R.layout.list, null);
			holder = new ViewHolder();
			holder.name = (TextView) convertView.findViewById(R.id.title);

			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}

		holder.name.setText(course.get(position));

		return convertView;

	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return course.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return course.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	static class ViewHolder {

		TextView name;
	}
}